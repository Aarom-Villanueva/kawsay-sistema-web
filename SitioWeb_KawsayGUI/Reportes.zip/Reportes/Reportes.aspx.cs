﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SitioWeb_KawsayGUI.Reportes
{
    public partial class Reportes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            string codigoTecnico = txtCodigoTecnico.Text.Trim();
            DateTime fechaInicio, fechaFin;

            // Validaciones
            if (string.IsNullOrEmpty(codigoTecnico))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alert",
                    "alert('Por favor ingrese el código del técnico');", true);
                return;
            }

            if (!DateTime.TryParse(txtFechaInicio.Text, out fechaInicio))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alert",
                    "alert('Por favor ingrese una fecha de inicio válida');", true);
                return;
            }

            if (!DateTime.TryParse(txtFechaFin.Text, out fechaFin))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alert",
                    "alert('Por favor ingrese una fecha de fin válida');", true);
                return;
            }

            if (fechaInicio > fechaFin)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alert",
                    "alert('La fecha de inicio no puede ser mayor a la fecha de fin');", true);
                return;
            }

            // Llamar a la capa de negocio para obtener los datos
            CargarDatosTecnico(codigoTecnico);
            CargarHistorial(codigoTecnico, fechaInicio, fechaFin);

            pnlInfo.Visible = true;
        }

        private void CargarDatosTecnico(string codigoTecnico)
        {
            // TODO: Reemplazar con tu lógica de negocio
            // Ejemplo: var tecnico = new TecnicoNegocio().ObtenerPorCodigo(codigoTecnico);

            lblPlaca.Text = "ACB-124";
            lblTecnico.Text = "Sebastian Salas Rojas";
            lblMarca.Text = "Dong Feng";
            lblDNI.Text = "45678912";
            lblModelo.Text = "DF-1417";
            lblLicencia.Text = "L76023842";
            lblNSerie.Text = "JTDZKUXH5123456";
            lblEstado.Text = "Activo";
        }

        private void CargarHistorial(string codigoTecnico, DateTime fechaInicio, DateTime fechaFin)
        {
            // TODO: Reemplazar con tu lógica de negocio
            // Ejemplo: var historial = new ServicioNegocio().ObtenerHistorialTecnico(codigoTecnico, fechaInicio, fechaFin);

            DataTable dt = new DataTable();
            dt.Columns.Add("Codigo", typeof(string));
            dt.Columns.Add("Tipo", typeof(string));
            dt.Columns.Add("Fecha", typeof(DateTime));
            dt.Columns.Add("Cliente", typeof(string));
            dt.Columns.Add("Ubicacion", typeof(string));
            dt.Columns.Add("Detalle", typeof(string));

            // Datos de ejemplo
            dt.Rows.Add("I00045", "Instalación", new DateTime(2024, 11, 15), "María González", "Villa El Salvador", "Purificador Premium P500");
            dt.Rows.Add("M00123", "Mantenimiento", new DateTime(2024, 11, 20), "Carlos Rodríguez", "San Juan de Miraflores", "Cambio de filtros y membrana");
            dt.Rows.Add("M00124", "Mantenimiento", new DateTime(2024, 11, 22), "Ana Torres", "Villa María del Triunfo", "Mantenimiento preventivo");
            dt.Rows.Add("I00046", "Instalación", new DateTime(2024, 11, 25), "Roberto Silva", "Chorrillos", "Purificador Estándar P300");
            dt.Rows.Add("M00125", "Mantenimiento", new DateTime(2024, 12, 01), "Luis Méndez", "Surco", "Reparación de válvula");

            gvHistorial.DataSource = dt;
            gvHistorial.DataBind();
        }
    }
}